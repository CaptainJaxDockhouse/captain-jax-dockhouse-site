import React from 'react'
import CaptainJaxDockhouse from './CaptainJaxDockhouse.jsx'

export default function App() {
  return <CaptainJaxDockhouse />
}
